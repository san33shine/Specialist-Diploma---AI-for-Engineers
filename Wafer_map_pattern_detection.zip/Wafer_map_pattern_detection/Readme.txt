https://www.kaggle.com/qingyi/wm811k-wafer-map -> link to dataset

I made some modification on the labelling, as instead of defining the pattern, at the moment I am interested in classifying whether pattern is detected or not. 